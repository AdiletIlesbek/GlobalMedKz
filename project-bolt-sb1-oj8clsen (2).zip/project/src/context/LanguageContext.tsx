import React, { createContext, useState, useContext, ReactNode } from 'react';
import { Language } from '../types';

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

const translations = {
  ru: {
    // Navigation
    'nav.home': 'Главная',
    'nav.doctors': 'Врачи',
    'nav.medications': 'Лекарства',
    'nav.profile': 'Профиль',
    'nav.login': 'Войти',
    'nav.register': 'Регистрация',
    'nav.logout': 'Выйти',
    
    // Landing page
    'landing.title': 'Ваше здоровье - наш приоритет',
    'landing.subtitle': 'Найдите лучших врачей и лекарства для лечения сложных заболеваний',
    'landing.features.doctors': 'Квалифицированные врачи',
    'landing.features.medications': 'Редкие лекарства',
    'landing.features.consultations': 'Онлайн консультации',
    'landing.features.delivery': 'Доставка на дом',
    'landing.cta': 'Начать сейчас',
    
    // Doctors
    'doctors.title': 'Наши специалисты',
    'doctors.search': 'Поиск врачей...',
    'doctors.filter': 'Фильтр по специализации',
    'doctors.experience': 'Опыт:',
    'doctors.rating': 'Рейтинг:',
    'doctors.price': 'Стоимость консультации:',
    'doctors.currency': '₸',
    'doctors.book': 'Записаться',
    'doctors.reviews': 'Отзывы',
    'doctors.leaveReview': 'Оставить отзыв',
    'doctors.reviewPlaceholder': 'Поделитесь своим опытом...',
    'doctors.submitReview': 'Отправить отзыв',
    
    // Medications
    'medications.title': 'Каталог лекарств',
    'medications.search': 'Поиск лекарств...',
    'medications.filter': 'Фильтр по категориям',
    'medications.price': 'Цена:',
    'medications.currency': '₸',
    'medications.buy': 'Купить',
    'medications.outOfStock': 'Нет в наличии',
    
    // Auth
    'auth.email': 'Электронная почта',
    'auth.password': 'Пароль',
    'auth.name': 'Имя',
    'auth.login': 'Войти',
    'auth.register': 'Зарегистрироваться',
    'auth.forgotPassword': 'Забыли пароль?',
    'auth.noAccount': 'Нет аккаунта?',
    'auth.hasAccount': 'Уже есть аккаунт?',
    
    // Profile
    'profile.title': 'Личный кабинет',
    'profile.consultations': 'Мои консультации',
    'profile.medications': 'Мои лекарства',
    'profile.orders': 'Мои заказы',
    'profile.settings': 'Настройки',
    'profile.changePhoto': 'Изменить фото',
    'profile.uploadPhoto': 'Загрузить фото',
    'profile.removePhoto': 'Удалить фото',
    
    // Consultation
    'consultation.book': 'Записаться на консультацию',
    'consultation.selectDate': 'Выберите дату',
    'consultation.selectTime': 'Выберите время',
    'consultation.confirm': 'Подтвердить',
    'consultation.paymentInstructions': 'Для подтверждения консультации, пожалуйста, выполните перевод на Kaspi:',
    'consultation.uploadReceipt': 'Загрузить чек',
    'consultation.startChat': 'Начать чат',
    
    // Chat
    'chat.sendMessage': 'Отправить сообщение',
    'chat.uploadFile': 'Загрузить файл',
    'chat.startVideo': 'Видеозвонок',
    'chat.endVideo': 'Завершить видеозвонок',
    
    // Payment
    'payment.title': 'Оплата',
    'payment.kaspi': 'Перевод на Kaspi',
    'payment.instructions': 'Переведите точную сумму на номер:',
    'payment.uploadReceipt': 'Загрузить чек об оплате',
    'payment.confirm': 'Подтвердить оплату',
    
    // Common
    'common.loading': 'Загрузка...',
    'common.error': 'Произошла ошибка',
    'common.success': 'Успешно',
    'common.save': 'Сохранить',
    'common.cancel': 'Отмена',
    'common.back': 'Назад',
    'common.next': 'Далее',
  },
  kz: {
    // Navigation
    'nav.home': 'Басты бет',
    'nav.doctors': 'Дәрігерлер',
    'nav.medications': 'Дәрі-дәрмектер',
    'nav.profile': 'Профиль',
    'nav.login': 'Кіру',
    'nav.register': 'Тіркелу',
    'nav.logout': 'Шығу',
    
    // Landing page
    'landing.title': 'Сіздің денсаулығыңыз - біздің басымдылығымыз',
    'landing.subtitle': 'Күрделі аурулардың емделуіне арналған үздік дәрігерлер мен дәрі-дәрмектерді табыңыз',
    'landing.features.doctors': 'Білікті дәрігерлер',
    'landing.features.medications': 'Сирек кездесетін дәрі-дәрмектер',
    'landing.features.consultations': 'Онлайн кеңес алу',
    'landing.features.delivery': 'Үйге жеткізу',
    'landing.cta': 'Қазір бастау',
    
    // Doctors
    'doctors.title': 'Біздің мамандар',
    'doctors.search': 'Дәрігерлерді іздеу...',
    'doctors.filter': 'Мамандығы бойынша сүзу',
    'doctors.experience': 'Тәжірибесі:',
    'doctors.rating': 'Рейтингі:',
    'doctors.price': 'Кеңес беру құны:',
    'doctors.currency': '₸',
    'doctors.book': 'Жазылу',
    'doctors.reviews': 'Пікірлер',
    'doctors.leaveReview': 'Пікір қалдыру',
    'doctors.reviewPlaceholder': 'Өз тәжірибеңізбен бөлісіңіз...',
    'doctors.submitReview': 'Пікір жіберу',
    
    // Medications
    'medications.title': 'Дәрі-дәрмектер каталогы',
    'medications.search': 'Дәрі-дәрмектерді іздеу...',
    'medications.filter': 'Санаттар бойынша сүзу',
    'medications.price': 'Бағасы:',
    'medications.currency': '₸',
    'medications.buy': 'Сатып алу',
    'medications.outOfStock': 'Қолда жоқ',
    
    // Auth
    'auth.email': 'Электрондық пошта',
    'auth.password': 'Құпия сөз',
    'auth.name': 'Аты',
    'auth.login': 'Кіру',
    'auth.register': 'Тіркелу',
    'auth.forgotPassword': 'Құпия сөзді ұмыттыңыз ба?',
    'auth.noAccount': 'Тіркелгіңіз жоқ па?',
    'auth.hasAccount': 'Тіркелгіңіз бар ма?',
    
    // Profile
    'profile.title': 'Жеке кабинет',
    'profile.consultations': 'Менің кеңестерім',
    'profile.medications': 'Менің дәрі-дәрмектерім',
    'profile.orders': 'Менің тапсырыстарым',
    'profile.settings': 'Параметрлер',
    'profile.changePhoto': 'Фотоны өзгерту',
    'profile.uploadPhoto': 'Фото жүктеу',
    'profile.removePhoto': 'Фотоны жою',
    
    // Consultation
    'consultation.book': 'Кеңес алуға жазылу',
    'consultation.selectDate': 'Күнді таңдаңыз',
    'consultation.selectTime': 'Уақытты таңдаңыз',
    'consultation.confirm': 'Растау',
    'consultation.paymentInstructions': 'Кеңесті растау үшін Kaspi-ге төлем жасаңыз:',
    'consultation.uploadReceipt': 'Чекті жүктеу',
    'consultation.startChat': 'Чатты бастау',
    
    // Chat
    'chat.sendMessage': 'Хабарлама жіберу',
    'chat.uploadFile': 'Файл жүктеу',
    'chat.startVideo': 'Бейне қоңырау',
    'chat.endVideo': 'Бейне қоңырауды аяқтау',
    
    // Payment
    'payment.title': 'Төлем',
    'payment.kaspi': 'Kaspi-ге аудару',
    'payment.instructions': 'Нақты соманы мына нөмірге аударыңыз:',
    'payment.uploadReceipt': 'Төлем чегін жүктеу',
    'payment.confirm': 'Төлемді растау',
    
    // Common
    'common.loading': 'Жүктелуде...',
    'common.error': 'Қате орын алды',
    'common.success': 'Сәтті',
    'common.save': 'Сақтау',
    'common.cancel': 'Болдырмау',
    'common.back': 'Артқа',
    'common.next': 'Келесі',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('ru');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};