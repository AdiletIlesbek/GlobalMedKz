import { Doctor, Medication, Consultation, Order } from '../types';

// Mock doctors data
export const doctors: Doctor[] = [
  {
    id: '1',
    name: 'Анна Петрова',
    specialization: 'Кардиолог',
    experience: 12,
    rating: 4.8,
    consultationPrice: 15000,
    availableSlots: ['2025-05-01T09:00', '2025-05-01T11:00', '2025-05-02T14:00'],
    avatar: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=300',
    languages: ['Русский', 'Казахский', 'Английский'],
    about: {
      ru: 'Опытный кардиолог с 12-летним опытом. Специализируется на диагностике и лечении сердечно-сосудистых заболеваний.',
      kz: '12 жылдық тәжірибесі бар тәжірибелі кардиолог. Жүрек-қан тамырлары ауруларын диагностикалау және емдеу бойынша маманданған.'
    }
  },
  {
    id: '2',
    name: 'Әсет Мұратұлы',
    specialization: 'Невролог',
    experience: 8,
    rating: 4.9,
    consultationPrice: 12000,
    availableSlots: ['2025-05-01T10:00', '2025-05-01T15:00', '2025-05-03T11:00'],
    avatar: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=300',
    languages: ['Казахский', 'Русский'],
    about: {
      ru: 'Невролог с 8-летним опытом работы. Специализируется на лечении заболеваний нервной системы.',
      kz: '8 жылдық тәжірибесі бар невролог. Жүйке жүйесінің ауруларын емдеуге маманданған.'
    }
  },
  {
    id: '3',
    name: 'Елена Иванова',
    specialization: 'Эндокринолог',
    experience: 15,
    rating: 4.7,
    consultationPrice: 18000,
    availableSlots: ['2025-05-02T09:00', '2025-05-02T12:00', '2025-05-04T15:00'],
    avatar: 'https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=300',
    languages: ['Русский', 'Английский'],
    about: {
      ru: 'Эндокринолог с 15-летним опытом. Специализируется на диагностике и лечении заболеваний эндокринной системы.',
      kz: '15 жылдық тәжірибесі бар эндокринолог. Эндокриндік жүйе ауруларын диагностикалау және емдеуге маманданған.'
    }
  },
  {
    id: '4',
    name: 'Марат Сұлтанов',
    specialization: 'Гастроэнтеролог',
    experience: 10,
    rating: 4.5,
    consultationPrice: 14000,
    availableSlots: ['2025-05-01T13:00', '2025-05-03T10:00', '2025-05-03T16:00'],
    avatar: 'https://images.pexels.com/photos/5214961/pexels-photo-5214961.jpeg?auto=compress&cs=tinysrgb&w=300',
    languages: ['Казахский', 'Русский', 'Английский'],
    about: {
      ru: 'Гастроэнтеролог с 10-летним опытом. Специализируется на диагностике и лечении заболеваний пищеварительной системы.',
      kz: '10 жылдық тәжірибесі бар гастроэнтеролог. Ас қорыту жүйесінің ауруларын диагностикалау және емдеуге маманданған.'
    }
  }
];

// Mock medications data
export const medications: Medication[] = [
  {
    id: '1',
    name: {
      ru: 'Кардиоплюс',
      kz: 'Кардиоплюс'
    },
    category: 'Кардиология',
    price: 8500,
    image: 'https://images.pexels.com/photos/4210610/pexels-photo-4210610.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
    description: {
      ru: 'Препарат для лечения сердечно-сосудистых заболеваний. Снижает риск сердечных приступов и инсультов.',
      kz: 'Жүрек-қан тамырлары ауруларын емдеуге арналған препарат. Жүрек талмасы мен инсульт қаупін төмендетеді.'
    },
    dosage: '1 таблетка в день',
    manufacturer: 'ФармаМед'
  },
  {
    id: '2',
    name: {
      ru: 'НейроСтим',
      kz: 'НейроСтим'
    },
    category: 'Неврология',
    price: 12000,
    image: 'https://images.pexels.com/photos/5214996/pexels-photo-5214996.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
    description: {
      ru: 'Препарат для улучшения мозгового кровообращения и когнитивных функций. Эффективен при лечении неврологических расстройств.',
      kz: 'Ми қан айналымы мен когнитивтік функцияларды жақсартуға арналған препарат. Неврологиялық бұзылыстарды емдеуде тиімді.'
    },
    dosage: '1 капсула 2 раза в день',
    manufacturer: 'НейроФарм'
  },
  {
    id: '3',
    name: {
      ru: 'Эндорегулин',
      kz: 'Эндорегулин'
    },
    category: 'Эндокринология',
    price: 15000,
    image: 'https://images.pexels.com/photos/3683098/pexels-photo-3683098.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: false,
    description: {
      ru: 'Препарат для нормализации работы эндокринной системы. Применяется при лечении сахарного диабета и гормональных нарушений.',
      kz: 'Эндокриндік жүйенің жұмысын қалыпқа келтіруге арналған препарат. Қант диабеті мен гормоналды бұзылыстарды емдеуде қолданылады.'
    },
    dosage: '1 таблетка перед едой',
    manufacturer: 'ЭндоМед'
  },
  {
    id: '4',
    name: {
      ru: 'ГастроЗащита',
      kz: 'ГастроҚорғаныс'
    },
    category: 'Гастроэнтерология',
    price: 7000,
    image: 'https://images.pexels.com/photos/3683041/pexels-photo-3683041.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
    description: {
      ru: 'Препарат для защиты и восстановления слизистой оболочки желудка. Применяется при лечении гастрита, язвы и других заболеваний ЖКТ.',
      kz: 'Асқазан шырышты қабатын қорғауға және қалпына келтіруге арналған препарат. Гастрит, жара және басқа да АІЖ ауруларын емдеуде қолданылады.'
    },
    dosage: '1 капсула 3 раза в день',
    manufacturer: 'ГастроФарм'
  }
];

// Mock consultations data
export const consultations: Consultation[] = [
  {
    id: '1',
    doctorId: '1',
    patientId: '1',
    dateTime: '2025-05-01T09:00',
    status: 'scheduled',
    paymentStatus: 'confirmed'
  },
  {
    id: '2',
    doctorId: '3',
    patientId: '1',
    dateTime: '2025-04-28T15:00',
    status: 'completed',
    paymentStatus: 'confirmed'
  }
];

// Mock orders data
export const orders: Order[] = [
  {
    id: '1',
    userId: '1',
    medications: [
      {
        medicationId: '1',
        quantity: 2
      },
      {
        medicationId: '4',
        quantity: 1
      }
    ],
    totalPrice: 24000,
    status: 'confirmed',
    paymentStatus: 'confirmed',
    deliveryAddress: 'г. Алматы, ул. Абая 45, кв. 12',
    orderDate: '2025-04-25'
  }
];