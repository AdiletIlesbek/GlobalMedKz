import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Search, Filter } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DoctorCard from '../components/DoctorCard';
import MedicationCard from '../components/MedicationCard';
import { doctors, medications } from '../data/mockData';

const MainPage: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'doctors' | 'medications'>('doctors');
  const [searchTerm, setSearchTerm] = useState('');
  const [doctorSpecialization, setDoctorSpecialization] = useState('');
  const [medicationCategory, setMedicationCategory] = useState('');

  // Get unique specializations and categories
  const specializations = [...new Set(doctors.map(doctor => doctor.specialization))];
  const categories = [...new Set(medications.map(medication => medication.category))];

  // Filter doctors based on search and specialization
  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doctor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialization = doctorSpecialization === '' || doctor.specialization === doctorSpecialization;
    
    return matchesSearch && matchesSpecialization;
  });

  // Filter medications based on search and category
  const filteredMedications = medications.filter(medication => {
    const matchesSearch = medication.name.ru.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          medication.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = medicationCategory === '' || medication.category === medicationCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Welcome section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              {t('landing.title')}
            </h1>
            <p className="text-gray-600">
              {user && <>Здравствуйте, <span className="font-semibold">{user.name}</span>. </>}
              Найдите лучших специалистов и лекарства для вашего здоровья.
            </p>
          </div>
          
          {/* Tabs */}
          <div className="mb-8 border-b border-gray-200">
            <div className="flex space-x-8">
              <button
                className={`pb-4 px-1 font-medium text-lg ${
                  activeTab === 'doctors'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('doctors')}
              >
                {t('nav.doctors')}
              </button>
              <button
                className={`pb-4 px-1 font-medium text-lg ${
                  activeTab === 'medications'
                    ? 'text-blue-600 border-b-2 border-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('medications')}
              >
                {t('nav.medications')}
              </button>
            </div>
          </div>
          
          {/* Search and Filter */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="relative flex-grow">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search size={20} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder={activeTab === 'doctors' ? t('doctors.search') : t('medications.search')}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              {/* Filter */}
              <div className="relative w-full md:w-1/3">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter size={20} className="text-gray-400" />
                </div>
                
                {activeTab === 'doctors' ? (
                  <select
                    value={doctorSpecialization}
                    onChange={(e) => setDoctorSpecialization(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white"
                  >
                    <option value="">{t('doctors.filter')}</option>
                    {specializations.map((specialization) => (
                      <option key={specialization} value={specialization}>
                        {specialization}
                      </option>
                    ))}
                  </select>
                ) : (
                  <select
                    value={medicationCategory}
                    onChange={(e) => setMedicationCategory(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white"
                  >
                    <option value="">{t('medications.filter')}</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>
          </div>
          
          {/* Content */}
          <div>
            {activeTab === 'doctors' ? (
              <>
                <h2 className="text-2xl font-semibold text-gray-800 mb-6">{t('doctors.title')}</h2>
                
                {filteredDoctors.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500">По вашему запросу ничего не найдено.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredDoctors.map((doctor) => (
                      <DoctorCard key={doctor.id} doctor={doctor} />
                    ))}
                  </div>
                )}
              </>
            ) : (
              <>
                <h2 className="text-2xl font-semibold text-gray-800 mb-6">{t('medications.title')}</h2>
                
                {filteredMedications.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500">По вашему запросу ничего не найдено.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredMedications.map((medication) => (
                      <MedicationCard key={medication.id} medication={medication} />
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default MainPage;