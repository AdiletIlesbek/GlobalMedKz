import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Calendar, Package, Settings, ArrowRight, Clock, FileCheck, Camera, Truck } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProfilePhotoModal from '../components/ProfilePhotoModal';
import { consultations, orders, medications, doctors } from '../data/mockData';

const ProfilePage: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<'consultations' | 'medications' | 'settings'>('consultations');
  const [showPhotoModal, setShowPhotoModal] = useState(false);

  // Filter consultations for the current user
  const userConsultations = consultations.filter(consultation => 
    consultation.patientId === user?.id
  );

  // Filter orders for the current user
  const userOrders = orders.filter(order => 
    order.userId === user?.id
  );

  // Get ordered medications details
  const userMedications = userOrders.flatMap(order => 
    order.medications.map(item => {
      const medicationDetails = medications.find(med => med.id === item.medicationId);
      return medicationDetails ? {
        ...medicationDetails,
        quantity: item.quantity,
        orderDate: order.orderDate,
        orderStatus: order.status,
        orderId: order.id
      } : null;
    }).filter(Boolean)
  );

  // Format date
  const formatDate = (dateString: string) => {
    if (dateString.includes('T')) {
      // DateTime format
      const date = new Date(dateString);
      
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      
      return `${day}.${month}.${year} ${hours}:${minutes}`;
    } else {
      // Date only format
      return dateString;
    }
  };

  const getOrderStatusSteps = (status: string) => {
    const steps = [
      { label: 'На складе', completed: true },
      { label: 'В обработке', completed: status !== 'pending' },
      { label: 'Подтвержден', completed: status === 'confirmed' || status === 'delivered' },
      { label: 'Доставлен', completed: status === 'delivered' }
    ];
    return steps;
  };

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Profile header */}
            <div className="bg-blue-600 p-6 text-white">
              <div className="flex flex-col md:flex-row items-center">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white mr-6 mb-4 md:mb-0">
                    {user.avatar ? (
                      <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                        <Camera size={32} className="text-gray-400" />
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => setShowPhotoModal(true)}
                    className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Camera size={24} className="text-white" />
                  </button>
                </div>
                <div>
                  <h1 className="text-2xl font-bold">{user.name}</h1>
                  <p className="text-blue-100">{user.email}</p>
                </div>
              </div>
            </div>
            
            {/* Tabs */}
            <div className="border-b border-gray-200">
              <div className="flex">
                <button
                  className={`px-6 py-3 font-medium text-sm ${
                    activeTab === 'consultations'
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  onClick={() => setActiveTab('consultations')}
                >
                  {t('profile.consultations')}
                </button>
                <button
                  className={`px-6 py-3 font-medium text-sm ${
                    activeTab === 'medications'
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  onClick={() => setActiveTab('medications')}
                >
                  {t('profile.medications')}
                </button>
                <button
                  className={`px-6 py-3 font-medium text-sm ${
                    activeTab === 'settings'
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  onClick={() => setActiveTab('settings')}
                >
                  {t('profile.settings')}
                </button>
              </div>
            </div>
            
            {/* Tab content */}
            <div className="p-6">
              {activeTab === 'consultations' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{t('profile.consultations')}</h2>
                  
                  {userConsultations.length === 0 ? (
                    <div className="text-center py-8 bg-gray-50 rounded-lg">
                      <Calendar size={48} className="mx-auto text-gray-400 mb-3" />
                      <p className="text-gray-600">У вас пока нет консультаций.</p>
                      <button
                        onClick={() => navigate('/doctors')}
                        className="mt-4 inline-flex items-center text-blue-600 hover:underline"
                      >
                        Найти врача
                        <ArrowRight size={16} className="ml-1" />
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {userConsultations.map(consultation => {
                        const doctor = doctors.find(d => d.id === consultation.doctorId);
                        
                        return (
                          <div key={consultation.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center">
                                <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                                  <img 
                                    src={doctor?.avatar || ''} 
                                    alt={doctor?.name || ''} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div>
                                  <h3 className="font-semibold text-gray-800">{doctor?.name}</h3>
                                  <p className="text-blue-600 text-sm">{doctor?.specialization}</p>
                                </div>
                              </div>
                              <div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  consultation.status === 'scheduled' 
                                    ? 'bg-blue-100 text-blue-700' 
                                    : consultation.status === 'completed'
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-red-100 text-red-700'
                                }`}>
                                  {consultation.status === 'scheduled' 
                                    ? 'Запланирована' 
                                    : consultation.status === 'completed'
                                    ? 'Завершена'
                                    : 'Отменена'
                                  }
                                </span>
                              </div>
                            </div>
                            
                            <div className="mt-3 flex items-center text-gray-600">
                              <Clock size={16} className="mr-1" />
                              <span>{formatDate(consultation.dateTime)}</span>
                            </div>
                            
                            <div className="mt-4 flex justify-between items-center">
                              <span className="text-gray-700">
                                Стоимость: <span className="font-medium">{doctor?.consultationPrice} ₸</span>
                              </span>
                              
                              {consultation.status === 'scheduled' && (
                                <button
                                  onClick={() => navigate('/consultation-chat')}
                                  className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm hover:bg-blue-700 transition-colors"
                                >
                                  {t('consultation.startChat')}
                                </button>
                              )}
                              
                              {consultation.status === 'completed' && (
                                <button
                                  onClick={() => navigate('/consultation-chat')}
                                  className="text-blue-600 hover:underline text-sm flex items-center"
                                >
                                  Просмотреть историю
                                  <ArrowRight size={14} className="ml-1" />
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
              
              {activeTab === 'medications' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{t('profile.medications')}</h2>
                  
                  {userMedications.length === 0 ? (
                    <div className="text-center py-8 bg-gray-50 rounded-lg">
                      <Package size={48} className="mx-auto text-gray-400 mb-3" />
                      <p className="text-gray-600">У вас пока нет заказанных лекарств.</p>
                      <button
                        onClick={() => navigate('/medications')}
                        className="mt-4 inline-flex items-center text-blue-600 hover:underline"
                      >
                        Перейти к каталогу
                        <ArrowRight size={16} className="ml-1" />
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-6">
                      {userMedications.map((item, index) => {
                        if (!item) return null;
                        
                        const steps = getOrderStatusSteps(item.orderStatus);
                        
                        return (
                          <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div className="flex flex-col md:flex-row md:items-center">
                              <div className="flex mb-4 md:mb-0 md:mr-6">
                                <div className="w-20 h-20 rounded overflow-hidden mr-4">
                                  <img 
                                    src={item.image} 
                                    alt={item.name.ru} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div>
                                  <h3 className="font-semibold text-gray-800">{item.name.ru}</h3>
                                  <p className="text-blue-600 text-sm">{item.category}</p>
                                  <div className="mt-1 text-gray-600 text-sm">
                                    Заказано: {formatDate(item.orderDate)}
                                  </div>
                                  <div className="text-gray-700 mt-1">
                                    <span className="text-sm">Количество: {item.quantity}</span>
                                    <div className="font-medium">
                                      {(item.price * item.quantity)} ₸
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex-grow">
                                <div className="relative">
                                  <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                                    <div 
                                      style={{ width: `${(steps.filter(step => step.completed).length / steps.length) * 100}%` }}
                                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-500"
                                    />
                                  </div>
                                  <div className="flex justify-between">
                                    {steps.map((step, stepIndex) => (
                                      <div 
                                        key={stepIndex}
                                        className={`flex flex-col items-center ${
                                          step.completed ? 'text-blue-600' : 'text-gray-400'
                                        }`}
                                      >
                                        <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 ${
                                          step.completed ? 'bg-blue-600 text-white' : 'bg-gray-200'
                                        }`}>
                                          {step.completed && <FileCheck size={14} />}
                                        </div>
                                        <span className="text-xs text-center">{step.label}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
              
              {activeTab === 'settings' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{t('profile.settings')}</h2>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-medium text-gray-800 mb-4">Личные данные</h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                          Имя
                        </label>
                        <input
                          type="text"
                          id="name"
                          value={user.name}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          readOnly
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          id="email"
                          value={user.email}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          readOnly
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                          Телефон
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          placeholder="+7 (7__) ___-__-__"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="address" className="block text-gray-700 font-medium mb-2">
                          Адрес
                        </label>
                        <input
                          type="text"
                          id="address"
                          placeholder="г. Алматы, ул. Абая 45, кв. 12"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        {t('common.save')}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      {showPhotoModal && (
        <ProfilePhotoModal onClose={() => setShowPhotoModal(false)} />
      )}
      
      <Footer />
    </div>
  );
};

export default ProfilePage;