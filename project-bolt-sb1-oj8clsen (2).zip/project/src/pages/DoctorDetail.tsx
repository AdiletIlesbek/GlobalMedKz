import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Star, Calendar, Clock, MapPin, Languages, ArrowLeft } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PaymentModal from '../components/PaymentModal';
import { doctors } from '../data/mockData';
import { Doctor } from '../types';

const DoctorDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t, language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    // Find doctor by id
    const foundDoctor = doctors.find(d => d.id === id);
    
    if (foundDoctor) {
      setDoctor(foundDoctor);
    } else {
      setError('Врач не найден');
    }
    
    setIsLoading(false);
  }, [id]);

  const handleSlotSelect = (slot: string) => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    setSelectedSlot(slot);
  };

  const handleBooking = () => {
    if (!selectedSlot) {
      setError('Пожалуйста, выберите время консультации');
      return;
    }
    
    setShowPaymentModal(true);
  };

  const handlePaymentConfirm = (receiptFile: File | null) => {
    // In a real app, we would upload the receipt and process the payment
    setShowPaymentModal(false);
    setSuccess(true);
    
    // Redirect to chat after 2 seconds
    setTimeout(() => {
      navigate('/consultation-chat');
    }, 2000);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    return {
      date: `${day}.${month}`,
      time: `${hours}:${minutes}`
    };
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow flex items-center justify-center">
          <p className="text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (error && !doctor) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow flex flex-col items-center justify-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button
            onClick={() => navigate('/main')}
            className="flex items-center text-blue-600 hover:underline"
          >
            <ArrowLeft size={16} className="mr-1" />
            Вернуться на главную
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  if (!doctor) return null;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-blue-600 hover:underline mb-6"
          >
            <ArrowLeft size={16} className="mr-1" />
            {t('common.back')}
          </button>
          
          {/* Success message */}
          {success && (
            <div className="mb-6 p-4 bg-green-50 text-green-800 rounded-lg">
              Консультация успешно забронирована! Перенаправление в чат...
            </div>
          )}
          
          {/* Error message */}
          {error && !success && (
            <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
              {error}
            </div>
          )}
          
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Doctor banner */}
            <div className="bg-blue-600 h-40 relative">
              <div className="absolute bottom-0 left-0 w-full transform translate-y-1/2 flex justify-center">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <img 
                    src={doctor.avatar} 
                    alt={doctor.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
            
            {/* Doctor info */}
            <div className="pt-20 px-6 pb-6">
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gray-800">{doctor.name}</h1>
                <p className="text-blue-600 font-medium">{doctor.specialization}</p>
                
                <div className="flex items-center justify-center mt-2">
                  <div className="flex items-center mr-4">
                    <Star size={18} className="text-yellow-500 mr-1" />
                    <span className="text-gray-700">{doctor.rating}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock size={18} className="text-gray-500 mr-1" />
                    <span className="text-gray-700">{doctor.experience} {doctor.experience > 4 ? 'лет' : 'года'}</span>
                  </div>
                </div>
              </div>
              
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-800 mb-3">О враче</h2>
                <p className="text-gray-600">
                  {doctor.about[language]}
                </p>
                
                <div className="mt-4">
                  <div className="flex items-center mb-2">
                    <Languages size={18} className="text-gray-500 mr-2" />
                    <span className="text-gray-700 font-medium">Языки: </span>
                    <span className="text-gray-600 ml-1">{doctor.languages.join(', ')}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <MapPin size={18} className="text-gray-500 mr-2" />
                    <span className="text-gray-700 font-medium">Локация: </span>
                    <span className="text-gray-600 ml-1">Онлайн консультации</span>
                  </div>
                </div>
              </div>
              
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-800 mb-3">{t('consultation.book')}</h2>
                
                <div className="mb-4">
                  <h3 className="text-lg font-medium text-gray-700 mb-3">{t('consultation.selectDate')}</h3>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {/* Group slots by date */}
                    {Array.from(new Set(doctor.availableSlots.map(slot => formatDate(slot).date))).map((date) => (
                      <button
                        key={date}
                        className="bg-blue-50 text-blue-600 font-medium py-2 px-4 rounded-lg hover:bg-blue-100 transition-colors"
                        // We're not implementing date selection in this demo
                      >
                        {date}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-gray-700 mb-3">{t('consultation.selectTime')}</h3>
                  
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                    {doctor.availableSlots.map((slot) => {
                      const { time } = formatDate(slot);
                      return (
                        <button
                          key={slot}
                          onClick={() => handleSlotSelect(slot)}
                          className={`py-2 px-3 rounded-lg font-medium transition-colors ${
                            selectedSlot === slot
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          {time}
                        </button>
                      );
                    })}
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-center bg-blue-50 p-4 rounded-lg mb-6">
                  <div className="text-gray-800 mb-4 sm:mb-0">
                    <span className="font-medium">Стоимость консультации:</span>
                    <span className="text-xl font-semibold text-blue-600 ml-2">
                      {doctor.consultationPrice} {t('doctors.currency')}
                    </span>
                  </div>
                  
                  <button
                    onClick={handleBooking}
                    disabled={!selectedSlot || success}
                    className={`bg-blue-600 text-white py-2 px-6 rounded-lg transition-colors ${
                      !selectedSlot || success
                        ? 'opacity-60 cursor-not-allowed'
                        : 'hover:bg-blue-700'
                    }`}
                  >
                    {t('consultation.confirm')}
                  </button>
                </div>
                
                <div className="text-gray-600 text-sm">
                  <p>* После подтверждения бронирования вам будет предложено выполнить оплату через Kaspi и загрузить чек.</p>
                  <p>* После подтверждения оплаты вы получите доступ к чату с врачом.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {showPaymentModal && (
        <PaymentModal
          amount={doctor.consultationPrice}
          onClose={() => setShowPaymentModal(false)}
          onConfirm={handlePaymentConfirm}
          type="consultation"
        />
      )}
      
      <Footer />
    </div>
  );
};

export default DoctorDetail;