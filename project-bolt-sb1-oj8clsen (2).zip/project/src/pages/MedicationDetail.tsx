import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, ShoppingCart, Plus, Minus, Check } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PaymentModal from '../components/PaymentModal';
import { medications } from '../data/mockData';
import { Medication } from '../types';

const MedicationDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t, language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [medication, setMedication] = useState<Medication | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [address, setAddress] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    // Find medication by id
    const foundMedication = medications.find(m => m.id === id);
    
    if (foundMedication) {
      setMedication(foundMedication);
    } else {
      setError('Лекарство не найдено');
    }
    
    setIsLoading(false);
  }, [id]);

  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress(e.target.value);
  };

  const handlePurchase = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (!address) {
      setError('Пожалуйста, укажите адрес доставки');
      return;
    }
    
    setError('');
    setShowPaymentModal(true);
  };

  const handlePaymentConfirm = (receiptFile: File | null) => {
    // In a real app, we would upload the receipt and process the payment
    setShowPaymentModal(false);
    setSuccess(true);
    
    // Redirect to profile after 2 seconds
    setTimeout(() => {
      navigate('/profile');
    }, 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow flex items-center justify-center">
          <p className="text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (error && !medication) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow flex flex-col items-center justify-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button
            onClick={() => navigate('/main')}
            className="flex items-center text-blue-600 hover:underline"
          >
            <ArrowLeft size={16} className="mr-1" />
            Вернуться на главную
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  if (!medication) return null;

  const totalPrice = medication.price * quantity;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-blue-600 hover:underline mb-6"
          >
            <ArrowLeft size={16} className="mr-1" />
            {t('common.back')}
          </button>
          
          {/* Success message */}
          {success && (
            <div className="mb-6 p-4 bg-green-50 text-green-800 rounded-lg">
              Заказ успешно оформлен! Он будет доступен в вашем профиле. Перенаправление...
            </div>
          )}
          
          {/* Error message */}
          {error && !success && (
            <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
              {error}
            </div>
          )}
          
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="flex flex-col md:flex-row">
              {/* Medication image */}
              <div className="md:w-1/3">
                <div className="h-full relative">
                  <img 
                    src={medication.image} 
                    alt={medication.name[language]} 
                    className="w-full h-full object-cover object-center"
                  />
                  {!medication.inStock && (
                    <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 text-sm font-medium rounded">
                      {t('medications.outOfStock')}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Medication info */}
              <div className="md:w-2/3 p-6">
                <div className="mb-4">
                  <div className="text-blue-600 font-medium mb-1">{medication.category}</div>
                  <h1 className="text-2xl font-bold text-gray-800">{medication.name[language]}</h1>
                  <div className="mt-2 text-gray-700">
                    <span className="font-medium">Производитель:</span> {medication.manufacturer}
                  </div>
                </div>
                
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">Описание</h2>
                  <p className="text-gray-600">
                    {medication.description[language]}
                  </p>
                </div>
                
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">Информация о препарате</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-gray-700 font-medium">Дозировка:</span>
                      <p className="text-gray-600">{medication.dosage}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-gray-700 font-medium">Категория:</span>
                      <p className="text-gray-600">{medication.category}</p>
                    </div>
                  </div>
                </div>
                
                {medication.inStock ? (
                  <div className="border-t border-gray-200 pt-6">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                      <div>
                        <div className="text-gray-700 font-medium">Стоимость:</div>
                        <div className="text-2xl font-semibold text-blue-600">
                          {medication.price} {t('medications.currency')}
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <span className="text-gray-700 mr-3">Количество:</span>
                        <div className="flex items-center border border-gray-300 rounded-lg">
                          <button 
                            onClick={decreaseQuantity}
                            disabled={quantity <= 1}
                            className={`px-3 py-1 text-gray-600 ${
                              quantity <= 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
                            }`}
                          >
                            <Minus size={16} />
                          </button>
                          <span className="px-3 py-1 text-gray-800 font-medium">{quantity}</span>
                          <button 
                            onClick={increaseQuantity}
                            className="px-3 py-1 text-gray-600 hover:bg-gray-100"
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <label htmlFor="address" className="block text-gray-700 font-medium mb-2">
                        Адрес доставки:
                      </label>
                      <input
                        type="text"
                        id="address"
                        value={address}
                        onChange={handleAddressChange}
                        placeholder="Введите адрес для доставки"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="mt-6 bg-blue-50 p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-gray-800 font-medium">Итого:</span>
                        <span className="text-xl font-semibold text-blue-600">
                          {totalPrice} {t('medications.currency')}
                        </span>
                      </div>
                      
                      <button
                        onClick={handlePurchase}
                        disabled={!medication.inStock || success}
                        className={`w-full bg-blue-600 text-white py-2 px-4 rounded-lg flex items-center justify-center transition-colors ${
                          !medication.inStock || success
                            ? 'opacity-60 cursor-not-allowed'
                            : 'hover:bg-blue-700'
                        }`}
                      >
                        <ShoppingCart size={18} className="mr-2" />
                        {t('medications.buy')}
                      </button>
                      
                      <div className="mt-2 text-xs text-gray-600 flex items-center">
                        <Check size={14} className="text-green-600 mr-1" />
                        Доставка в течение 1-3 дней
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="border-t border-gray-200 pt-6">
                    <div className="bg-red-50 p-4 rounded-lg text-center">
                      <p className="text-red-700 font-medium">К сожалению, данный препарат временно отсутствует на складе.</p>
                      <p className="text-gray-600 mt-2">Пожалуйста, проверьте наличие позже или обратитесь к врачу для подбора аналога.</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {showPaymentModal && (
        <PaymentModal
          amount={totalPrice}
          onClose={() => setShowPaymentModal(false)}
          onConfirm={handlePaymentConfirm}
          type="medication"
        />
      )}
      
      <Footer />
    </div>
  );
};

export default MedicationDetail;