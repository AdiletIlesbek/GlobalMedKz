import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Mail, Lock, ArrowRight } from 'lucide-react';

const Login: React.FC = () => {
  const { t } = useLanguage();
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setError('Пожалуйста, заполните все поля');
      return;
    }
    
    try {
      setIsLoading(true);
      setError('');
      
      await login(email, password);
      navigate('/main');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Неверный email или пароль';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex-grow flex items-center justify-center py-16 px-4 mt-16">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden flex max-w-4xl w-full">
          {/* Left image section */}
          <div className="hidden md:block w-1/2 bg-blue-600">
            <img 
              src="https://images.pexels.com/photos/4386464/pexels-photo-4386464.jpeg?auto=compress&cs=tinysrgb&w=600" 
              alt="Healthcare" 
              className="w-full h-full object-cover opacity-85"
            />
          </div>
          
          {/* Right form section */}
          <div className="w-full md:w-1/2 p-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">{t('auth.login')}</h2>
              <p className="text-gray-600">Войдите в свой аккаунт для доступа к услугам</p>
            </div>
            
            <form onSubmit={handleSubmit}>
              {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg">
                  {error}
                </div>
              )}
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                  {t('auth.email')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="example@mail.com"
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor="password" className="block text-gray-700 font-medium">
                    {t('auth.password')}
                  </label>
                  <Link to="/forgot-password" className="text-sm text-blue-600 hover:underline">
                    {t('auth.forgotPassword')}
                  </Link>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="••••••"
                  />
                </div>
              </div>
              
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full bg-blue-600 text-white py-2 px-4 rounded-lg flex items-center justify-center ${
                  isLoading ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700'
                } transition-colors`}
              >
                {isLoading ? t('common.loading') : t('auth.login')}
                {!isLoading && <ArrowRight size={18} className="ml-2" />}
              </button>
              
              {/* For demo purposes - quick login buttons */}
              <div className="mt-4 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setEmail('patient@example.com');
                    setPassword('password');
                  }}
                  className="bg-gray-100 text-gray-800 py-2 px-4 rounded-lg text-sm hover:bg-gray-200 transition-colors"
                >
                  Demo: Пациент
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEmail('doctor@example.com');
                    setPassword('password');
                  }}
                  className="bg-gray-100 text-gray-800 py-2 px-4 rounded-lg text-sm hover:bg-gray-200 transition-colors"
                >
                  Demo: Врач
                </button>
              </div>
            </form>
            
            <div className="mt-6 text-center text-gray-600">
              {t('auth.noAccount')} {' '}
              <Link to="/register" className="text-blue-600 hover:underline">
                {t('auth.register')}
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Login;