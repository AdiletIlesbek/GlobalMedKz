import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { Activity, Pill, Video, Truck, ArrowRight, Search, Star, CreditCard } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const LandingPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 bg-gradient-to-br from-blue-700 to-blue-500 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                {t('landing.title')}
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-blue-100">
                {t('landing.subtitle')}
              </p>
              <Link 
                to="/register" 
                className="bg-white text-blue-700 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors inline-flex items-center"
              >
                {t('landing.cta')}
                <ArrowRight size={20} className="ml-2" />
              </Link>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img 
                src="https://images.pexels.com/photos/7578906/pexels-photo-7578906.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Doctor with patient" 
                className="rounded-lg shadow-2xl max-w-full md:max-w-md h-auto"
              />
            </div>
          </div>
        </div>
        
        {/* Wave Separator */}
        <div className="w-full">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" className="fill-white">
            <path d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"></path>
          </svg>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Наши преимущества</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-blue-50 p-6 rounded-lg text-center transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Activity size={32} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{t('landing.features.doctors')}</h3>
              <p className="text-gray-600">Консультации с опытными специалистами со всего Казахстана.</p>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg text-center transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Pill size={32} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{t('landing.features.medications')}</h3>
              <p className="text-gray-600">Доступ к редким и специализированным лекарствам для сложных заболеваний.</p>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg text-center transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Video size={32} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{t('landing.features.consultations')}</h3>
              <p className="text-gray-600">Удобные онлайн консультации с видеосвязью и обменом файлами.</p>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg text-center transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck size={32} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{t('landing.features.delivery')}</h3>
              <p className="text-gray-600">Быстрая и безопасная доставка медикаментов прямо к вашей двери.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Как это работает</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 text-white font-bold text-xl">1</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Найдите специалиста</h3>
              <p className="text-center text-gray-600">Выберите врача нужной специализации из нашего каталога.</p>
              <div className="mt-4">
                <Search size={48} className="text-blue-500" />
              </div>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 text-white font-bold text-xl">2</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Получите консультацию</h3>
              <p className="text-center text-gray-600">Оплатите и получите онлайн консультацию в удобное для вас время.</p>
              <div className="mt-4">
                <Video size={48} className="text-blue-500" />
              </div>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 text-white font-bold text-xl">3</div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Заказывайте лекарства</h3>
              <p className="text-center text-gray-600">Получайте необходимые лекарства с доставкой на дом.</p>
              <div className="mt-4">
                <Truck size={48} className="text-blue-500" />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Отзывы наших пациентов</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
              </div>
              <p className="text-gray-600 mb-4">"Благодаря GlobalMed я смогла найти редкое лекарство для моей мамы, которое не было доступно в обычных аптеках. Очень удобный сервис!"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                  <img src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=100" alt="Аида Т." className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Аида Т.</p>
                  <p className="text-sm text-gray-500">Алматы</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
              </div>
              <p className="text-gray-600 mb-4">"Онлайн консультация с кардиологом помогла мне получить второе мнение, не выходя из дома. Профессиональный подход и удобство!"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                  <img src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100" alt="Марат С." className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Марат С.</p>
                  <p className="text-sm text-gray-500">Нур-Султан</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-yellow-500" />
                <Star size={20} className="text-gray-300" />
              </div>
              <p className="text-gray-600 mb-4">"Быстрая доставка лекарств очень выручает, когда нет возможности выйти из дома. Всё приходит в срок и хорошо упаковано."</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                  <img src="https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100" alt="Елена И." className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Елена И.</p>
                  <p className="text-sm text-gray-500">Шымкент</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Готовы начать?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">Присоединяйтесь к тысячам пациентов, которые уже получают качественную медицинскую помощь с GlobalMed.</p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Link 
              to="/register" 
              className="bg-white text-blue-700 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Зарегистрироваться
            </Link>
            <Link 
              to="/login" 
              className="border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Войти
            </Link>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default LandingPage;