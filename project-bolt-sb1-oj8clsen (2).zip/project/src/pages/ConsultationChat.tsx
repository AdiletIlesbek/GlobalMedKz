import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Send, Paperclip, Video, X, ArrowLeft } from 'lucide-react';
import Header from '../components/Header';
import { doctors } from '../data/mockData';

interface Message {
  id: string;
  content: string;
  senderId: string;
  isFile?: boolean;
  fileName?: string;
  timestamp: Date;
}

const ConsultationChat: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // The doctor for this consultation (hardcoded for demo)
  const doctor = doctors[0];

  // Auto-scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load initial messages
  useEffect(() => {
    // Add some sample messages
    const initialMessages: Message[] = [
      {
        id: '1',
        content: 'Здравствуйте! Я доктор Анна Петрова. Чем я могу вам помочь сегодня?',
        senderId: doctor.id,
        timestamp: new Date(new Date().getTime() - 60000 * 10) // 10 minutes ago
      }
    ];
    
    setMessages(initialMessages);
  }, []);

  const handleSendMessage = () => {
    if (message.trim() || file) {
      // Create a new message
      const newMessage: Message = {
        id: String(messages.length + 1),
        content: message.trim(),
        senderId: user?.id || '',
        isFile: !!file,
        fileName: file?.name,
        timestamp: new Date()
      };
      
      setMessages([...messages, newMessage]);
      setMessage('');
      setFile(null);
      
      // Simulate doctor reply after 1 second
      setTimeout(() => {
        const doctorReply: Message = {
          id: String(messages.length + 2),
          content: 'Спасибо за информацию. Я ознакомлюсь с ней и вскоре дам вам рекомендации.',
          senderId: doctor.id,
          timestamp: new Date()
        };
        
        setMessages(prevMessages => [...prevMessages, doctorReply]);
      }, 1000);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleVideoCall = () => {
    setShowVideoCall(!showVideoCall);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <main className="flex-grow pt-20">
        <div className="container mx-auto px-4 py-6">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden h-[calc(100vh-160px)] flex flex-col">
            {/* Chat header */}
            <div className="bg-blue-600 text-white p-4 flex justify-between items-center">
              <div className="flex items-center">
                <button 
                  onClick={() => navigate(-1)}
                  className="mr-3 p-1 hover:bg-blue-700 rounded-full"
                >
                  <ArrowLeft size={20} />
                </button>
                
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                    <img 
                      src={doctor.avatar} 
                      alt={doctor.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-semibold">{doctor.name}</h3>
                    <p className="text-sm text-blue-100">{doctor.specialization}</p>
                  </div>
                </div>
              </div>
              
              <button 
                className="p-2 hover:bg-blue-700 rounded-full"
                onClick={toggleVideoCall}
              >
                <Video size={20} />
              </button>
            </div>
            
            {/* Messages area */}
            <div className="flex-grow overflow-y-auto p-4">
              <div className="space-y-4">
                {messages.map((msg) => {
                  const isDoctor = msg.senderId === doctor.id;
                  return (
                    <div 
                      key={msg.id}
                      className={`flex ${isDoctor ? 'justify-start' : 'justify-end'}`}
                    >
                      {isDoctor && (
                        <div className="w-8 h-8 rounded-full overflow-hidden mr-2 flex-shrink-0">
                          <img 
                            src={doctor.avatar} 
                            alt={doctor.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      
                      <div 
                        className={`max-w-xs md:max-w-md p-3 rounded-lg ${
                          isDoctor
                            ? 'bg-blue-600 text-white rounded-bl-none' 
                            : 'bg-green-600 text-white rounded-br-none'
                        }`}
                      >
                        {msg.isFile ? (
                          <div className="flex items-center">
                            <Paperclip size={16} className="mr-2" />
                            <span className="underline">{msg.fileName || 'Файл'}</span>
                          </div>
                        ) : (
                          <p>{msg.content}</p>
                        )}
                        <div 
                          className={`text-xs mt-1 text-right ${
                            isDoctor ? 'text-blue-100' : 'text-green-100'
                          }`}
                        >
                          {formatTime(msg.timestamp)}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
            </div>
            
            {/* File preview */}
            {file && (
              <div className="px-4 py-2 bg-gray-50 border-t border-gray-200">
                <div className="flex items-center">
                  <Paperclip size={16} className="text-gray-500 mr-2" />
                  <span className="text-gray-700 text-sm">{file.name}</span>
                  <button 
                    onClick={() => setFile(null)}
                    className="ml-2 text-gray-500 hover:text-gray-700"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            )}
            
            {/* Message input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-center">
                <label className="mr-2 text-gray-500 hover:text-gray-700 cursor-pointer">
                  <Paperclip size={20} />
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileChange}
                  />
                </label>
                
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={t('chat.sendMessage')}
                  className="flex-grow px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  rows={1}
                />
                
                <button
                  onClick={handleSendMessage}
                  disabled={!message.trim() && !file}
                  className={`ml-2 p-2 rounded-full ${
                    message.trim() || file
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Video call modal */}
      {showVideoCall && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="w-full max-w-4xl bg-black rounded-lg overflow-hidden">
            <div className="relative">
              {/* Main video (doctor) */}
              <img 
                src="https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Video call" 
                className="w-full h-[70vh] object-cover"
              />
              
              {/* Small video (user) */}
              <div className="absolute bottom-4 right-4 w-1/4 h-1/4 bg-gray-800 rounded-lg overflow-hidden border-2 border-white">
                <img 
                  src={user.avatar || "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300"}
                  alt="User video" 
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Controls */}
              <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                <button 
                  className="bg-red-600 text-white p-3 rounded-full hover:bg-red-700"
                  onClick={toggleVideoCall}
                >
                  <X size={24} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsultationChat;