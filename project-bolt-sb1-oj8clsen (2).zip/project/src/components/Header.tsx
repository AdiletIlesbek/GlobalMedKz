import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User, ShoppingBag, Globe } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

const Header: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { isAuthenticated, user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ru' ? 'kz' : 'ru');
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="bg-white shadow-md fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to={isAuthenticated ? '/main' : '/'} className="text-2xl font-bold text-blue-600 flex items-center">
            <span className="text-blue-600 mr-2">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
              </svg>
            </span>
            GlobalMed
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {isAuthenticated ? (
              <>
                <Link to="/main" className={`text-gray-700 hover:text-blue-600 ${isActive('/main') ? 'text-blue-600 font-medium' : ''}`}>
                  {t('nav.home')}
                </Link>
                <Link to="/doctors" className={`text-gray-700 hover:text-blue-600 ${isActive('/doctors') ? 'text-blue-600 font-medium' : ''}`}>
                  {t('nav.doctors')}
                </Link>
                <Link to="/medications" className={`text-gray-700 hover:text-blue-600 ${isActive('/medications') ? 'text-blue-600 font-medium' : ''}`}>
                  {t('nav.medications')}
                </Link>
              </>
            ) : null}
          </nav>

          {/* Right side - Auth & Language */}
          <div className="hidden md:flex items-center space-x-6">
            <button 
              onClick={toggleLanguage}
              className="flex items-center text-gray-700 hover:text-blue-600"
            >
              <Globe size={20} className="mr-1" />
              <span>{language.toUpperCase()}</span>
            </button>

            {isAuthenticated ? (
              <div className="flex items-center space-x-6">
                <Link to="/profile" className="flex items-center text-gray-700 hover:text-blue-600">
                  {user?.avatar ? (
                    <img 
                      src={user.avatar} 
                      alt={user.name} 
                      className="w-8 h-8 rounded-full object-cover mr-2"
                    />
                  ) : (
                    <User size={20} className="mr-1" />
                  )}
                  <span>{t('nav.profile')}</span>
                </Link>
                <button 
                  onClick={logout}
                  className="text-gray-700 hover:text-blue-600"
                >
                  {t('nav.logout')}
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link to="/login" className="text-gray-700 hover:text-blue-600">
                  {t('nav.login')}
                </Link>
                <Link to="/register" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">
                  {t('nav.register')}
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-gray-700" onClick={toggleMenu}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-2">
            <nav className="flex flex-col space-y-4">
              {isAuthenticated ? (
                <>
                  <Link 
                    to="/main" 
                    className={`text-gray-700 hover:text-blue-600 ${isActive('/main') ? 'text-blue-600 font-medium' : ''}`}
                    onClick={toggleMenu}
                  >
                    {t('nav.home')}
                  </Link>
                  <Link 
                    to="/doctors" 
                    className={`text-gray-700 hover:text-blue-600 ${isActive('/doctors') ? 'text-blue-600 font-medium' : ''}`}
                    onClick={toggleMenu}
                  >
                    {t('nav.doctors')}
                  </Link>
                  <Link 
                    to="/medications" 
                    className={`text-gray-700 hover:text-blue-600 ${isActive('/medications') ? 'text-blue-600 font-medium' : ''}`}
                    onClick={toggleMenu}
                  >
                    {t('nav.medications')}
                  </Link>
                  <Link 
                    to="/profile" 
                    className={`text-gray-700 hover:text-blue-600 ${isActive('/profile') ? 'text-blue-600 font-medium' : ''}`}
                    onClick={toggleMenu}
                  >
                    {t('nav.profile')}
                  </Link>
                  <button 
                    onClick={() => {
                      logout();
                      toggleMenu();
                    }}
                    className="text-gray-700 hover:text-blue-600 text-left"
                  >
                    {t('nav.logout')}
                  </button>
                </>
              ) : (
                <>
                  <Link 
                    to="/login" 
                    className="text-gray-700 hover:text-blue-600"
                    onClick={toggleMenu}
                  >
                    {t('nav.login')}
                  </Link>
                  <Link 
                    to="/register" 
                    className="text-gray-700 hover:text-blue-600"
                    onClick={toggleMenu}
                  >
                    {t('nav.register')}
                  </Link>
                </>
              )}
              <button 
                onClick={() => {
                  toggleLanguage();
                  toggleMenu();
                }}
                className="flex items-center text-gray-700 hover:text-blue-600"
              >
                <Globe size={20} className="mr-2" />
                <span>{language === 'ru' ? 'Қазақша' : 'Русский'}</span>
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;