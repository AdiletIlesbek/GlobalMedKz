import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Medication } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface MedicationCardProps {
  medication: Medication;
}

const MedicationCard: React.FC<MedicationCardProps> = ({ medication }) => {
  const { t, language } = useLanguage();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="relative">
        <img 
          src={medication.image} 
          alt={medication.name[language]} 
          className="w-full h-48 object-cover object-center"
        />
        {!medication.inStock && (
          <div className="absolute top-0 right-0 bg-red-600 text-white px-3 py-1 text-sm font-medium">
            {t('medications.outOfStock')}
          </div>
        )}
      </div>
      <div className="p-6">
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-1">{medication.name[language]}</h3>
          <p className="text-blue-600 font-medium">{medication.category}</p>
        </div>
        
        <div className="mt-3">
          <p className="text-gray-600 line-clamp-3">
            {medication.description[language]}
          </p>
        </div>
        
        <div className="mt-3 text-gray-600">
          <p className="flex items-center"><span className="font-medium">Дозировка:</span> <span className="ml-2">{medication.dosage}</span></p>
          <p className="flex items-center mt-1"><span className="font-medium">Производитель:</span> <span className="ml-2">{medication.manufacturer}</span></p>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="text-gray-800 font-semibold text-lg">
            {t('medications.price')} <span className="text-blue-600">{medication.price} {t('medications.currency')}</span>
          </div>
          <Link 
            to={`/medications/${medication.id}`}
            className={`flex items-center px-4 py-2 rounded transition-colors ${medication.inStock 
              ? 'bg-blue-600 text-white hover:bg-blue-700' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'}`}
            onClick={(e) => !medication.inStock && e.preventDefault()}
          >
            <ShoppingCart size={18} className="mr-2" />
            {t('medications.buy')}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MedicationCard;