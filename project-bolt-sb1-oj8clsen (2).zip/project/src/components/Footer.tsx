import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-gray-900 text-white pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and company info */}
          <div className="col-span-1">
            <Link to="/" className="text-2xl font-bold flex items-center text-white">
              <span className="text-blue-400 mr-2">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
              </span>
              GlobalMed
            </Link>
            <p className="mt-4 text-gray-400">
              {t('landing.subtitle')}
            </p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-white">Быстрые ссылки</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/doctors" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.doctors')}
                </Link>
              </li>
              <li>
                <Link to="/medications" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.medications')}
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.login')}
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.register')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-white">Услуги</h3>
            <ul className="space-y-2">
              <li className="text-gray-400">Онлайн консультации</li>
              <li className="text-gray-400">Поиск лекарств</li>
              <li className="text-gray-400">Доставка медикаментов</li>
              <li className="text-gray-400">Медицинские советы</li>
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-white">Контакты</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={20} className="text-blue-400 mt-1 mr-2 flex-shrink-0" />
                <span className="text-gray-400">пр. Абая 52, Алматы, Казахстан</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="text-blue-400 mr-2 flex-shrink-0" />
                <span className="text-gray-400">+7 771 659 27 06</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="text-blue-400 mr-2 flex-shrink-0" />
                <span className="text-gray-400">info@globalmed.kz</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <p className="text-gray-500 text-center">
            &copy; {new Date().getFullYear()} GlobalMed. Все права защищены.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;