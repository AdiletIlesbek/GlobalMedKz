import React, { useState, useRef } from 'react';
import { X, Upload, Camera, Trash } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

interface ProfilePhotoModalProps {
  onClose: () => void;
}

const ProfilePhotoModal: React.FC<ProfilePhotoModalProps> = ({ onClose }) => {
  const { t } = useLanguage();
  const { user, updateProfilePhoto } = useAuth();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = async () => {
    if (selectedFile) {
      // In a real app, we would upload the file to a server
      // For demo purposes, we'll use the preview URL
      updateProfilePhoto(previewUrl);
      onClose();
    }
  };

  const handleRemovePhoto = () => {
    updateProfilePhoto(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-6 border-b">
          <h3 className="text-xl font-semibold text-gray-800">{t('profile.changePhoto')}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-6">
            <div className="flex justify-center">
              <div className="relative w-32 h-32 rounded-full overflow-hidden bg-gray-100">
                {(previewUrl || user?.avatar) ? (
                  <img 
                    src={previewUrl || user?.avatar || ''} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Camera size={40} className="text-gray-400" />
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-6">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
              
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
                >
                  <Upload size={20} />
                  {t('profile.uploadPhoto')}
                </button>
                
                {user?.avatar && (
                  <button
                    onClick={handleRemovePhoto}
                    className="flex items-center justify-center gap-2 bg-red-100 text-red-600 px-4 py-2 rounded hover:bg-red-200 transition-colors"
                  >
                    <Trash size={20} />
                    {t('profile.removePhoto')}
                  </button>
                )}
              </div>
            </div>
          </div>
          
          {selectedFile && (
            <div className="flex justify-end gap-3">
              <button 
                onClick={onClose}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                {t('common.cancel')}
              </button>
              <button
                onClick={handleUpload}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
              >
                {t('common.save')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePhotoModal;