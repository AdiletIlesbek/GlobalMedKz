import React from 'react';
import { Star, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Doctor } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface DoctorCardProps {
  doctor: Doctor;
}

const DoctorCard: React.FC<DoctorCardProps> = ({ doctor }) => {
  const { t, language } = useLanguage();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="relative pb-2/3">
        <img 
          src={doctor.avatar} 
          alt={doctor.name} 
          className="w-full h-48 object-cover object-center"
        />
      </div>
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-semibold text-gray-800 mb-1">{doctor.name}</h3>
            <p className="text-blue-600 font-medium">{doctor.specialization}</p>
          </div>
          <div className="flex items-center bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
            <Star size={16} className="text-yellow-500 mr-1" />
            <span>{doctor.rating}</span>
          </div>
        </div>
        
        <div className="mt-4">
          <p className="text-gray-600 line-clamp-3">
            {doctor.about[language]}
          </p>
        </div>
        
        <div className="mt-4 flex items-center text-gray-600">
          <Clock size={16} className="mr-1" />
          <span>{t('doctors.experience')} {doctor.experience} {doctor.experience > 4 ? 'лет' : 'года'}</span>
        </div>
        
        <div className="mt-2 flex flex-wrap gap-2">
          {doctor.languages.map((lang, index) => (
            <span 
              key={index} 
              className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full"
            >
              {lang}
            </span>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="text-gray-800 font-medium">
            {t('doctors.price')} <span className="text-blue-600">{doctor.consultationPrice} {t('doctors.currency')}</span>
          </div>
          <Link 
            to={`/doctors/${doctor.id}`}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
          >
            {t('doctors.book')}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;