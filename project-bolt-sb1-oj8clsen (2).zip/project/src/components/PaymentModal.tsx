import React, { useState } from 'react';
import { X, Upload, Check } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface PaymentModalProps {
  amount: number;
  onClose: () => void;
  onConfirm: (receiptFile: File | null) => void;
  type: 'consultation' | 'medication';
}

const PaymentModal: React.FC<PaymentModalProps> = ({ amount, onClose, onConfirm, type }) => {
  const { t } = useLanguage();
  const [receipt, setReceipt] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setReceipt(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      onConfirm(receipt);
      setIsUploading(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-6 border-b">
          <h3 className="text-xl font-semibold text-gray-800">{t('payment.title')}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-6">
            <h4 className="text-lg font-medium text-gray-800 mb-2">{t('payment.kaspi')}</h4>
            <p className="text-gray-600 mb-4">{t('payment.instructions')}</p>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-gray-700">GlobalMed</span>
                <span className="font-mono text-blue-800">+7 771 659 27 06</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="font-semibold text-gray-700">{t('medications.price')}</span>
                <span className="font-mono text-blue-800">{amount} {t('doctors.currency')}</span>
              </div>
            </div>
            
            <div className="text-gray-600 text-sm">
              <p className="mb-2">1. Откройте приложение Kaspi.kz</p>
              <p className="mb-2">2. Выберите "Переводы"</p>
              <p className="mb-2">3. Введите номер телефона и сумму</p>
              <p className="mb-2">4. Сделайте скриншот или сохраните чек</p>
              <p>5. Загрузите чек ниже</p>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label className="block text-gray-700 font-medium mb-2">
                {t('payment.uploadReceipt')}
              </label>
              
              {receipt ? (
                <div className="border border-green-300 bg-green-50 rounded-lg p-4 flex items-center">
                  <Check size={20} className="text-green-600 mr-2" />
                  <span className="text-green-800">{receipt.name}</span>
                  <button 
                    type="button"
                    onClick={() => setReceipt(null)}
                    className="ml-auto text-gray-500 hover:text-gray-700"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload size={32} className="mx-auto text-gray-400 mb-2" />
                  <p className="text-gray-600 mb-2">Перетащите файл сюда или нажмите для выбора</p>
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden" 
                    id="receipt-upload" 
                  />
                  <label 
                    htmlFor="receipt-upload"
                    className="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    Выбрать файл
                  </label>
                </div>
              )}
            </div>
            
            <div className="flex justify-end gap-3">
              <button 
                type="button"
                onClick={onClose}
                className="bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300 transition-colors"
              >
                {t('common.cancel')}
              </button>
              <button 
                type="submit"
                disabled={!receipt || isUploading}
                className={`bg-blue-600 text-white px-4 py-2 rounded transition-colors ${
                  !receipt || isUploading ? 'opacity-60 cursor-not-allowed' : 'hover:bg-blue-700'
                }`}
              >
                {isUploading ? t('common.loading') : t('payment.confirm')}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;