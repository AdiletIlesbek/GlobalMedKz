// Type definitions for the application

export interface User {
  id: string;
  name: string;
  email: string;
  isDoctor: boolean;
  specialization?: string;
  avatar?: string;
  reviews?: Review[];
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  experience: number;
  rating: number;
  consultationPrice: number;
  availableSlots: string[];
  avatar: string;
  languages: string[];
  about: {
    ru: string;
    kz: string;
  };
  reviews?: Review[];
}

export interface Review {
  id: string;
  userId: string;
  doctorId: string;
  rating: number;
  comment: string;
  date: string;
  userName: string;
  userAvatar?: string;
}

export interface Medication {
  id: string;
  name: {
    ru: string;
    kz: string;
  };
  category: string;
  price: number;
  image: string;
  inStock: boolean;
  description: {
    ru: string;
    kz: string;
  };
  dosage: string;
  manufacturer: string;
}

export interface Consultation {
  id: string;
  doctorId: string;
  patientId: string;
  dateTime: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'confirmed';
  paymentReceipt?: string;
}

export interface Message {
  id: string;
  consultationId: string;
  senderId: string;
  content: string;
  timestamp: string;
  isFile?: boolean;
  fileUrl?: string;
}

export interface Order {
  id: string;
  userId: string;
  medications: {
    medicationId: string;
    quantity: number;
  }[];
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'delivered';
  paymentStatus: 'pending' | 'confirmed';
  paymentReceipt?: string;
  deliveryAddress: string;
  orderDate: string;
}

export type Language = 'ru' | 'kz';